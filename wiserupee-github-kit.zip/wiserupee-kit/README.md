# ₹ WiseRupee

**AI-powered personal finance planner for Indian households.**
Split your salary by life stage, understand your spending pattern, and get a clear investment plan.

[**Live demo**](https://rupee-wise-life-planner.lovable.app/) · [Architecture](docs/ARCHITECTURE.md) · [Features](docs/FEATURES.md) · [Roadmap](docs/ROADMAP.md)

![Status](https://img.shields.io/badge/status-prototype-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5.x-3178c6)
![React](https://img.shields.io/badge/React-19-61dafb)
![License](https://img.shields.io/badge/license-MIT-green)

> Built for the **Compute50 – Golden Jubilee National Level Hackathon**, PSG College of Technology (FinTech / AI for Financial Inclusion).

---

## Problem

How can AI help individuals plan monthly income, reduce unnecessary spending, grow savings and make smarter financial decisions using their lifestyle, marital status and spending behaviour?

## Solution

WiseRupee is a personal money coach whose recommendations adapt to **real behaviour**, not a one-size-fits-all budget.

| Feature | What it does |
| --- | --- |
| Life-stage budget | Splits monthly salary for bachelors or married households (with or without children) |
| Expense tracking | Log expenses and group them into clear categories |
| Spending insights | Identifies your pattern (saver, weekend spender, stretched thin) and suggests fixes |
| Investment plan | Emergency fund, insurance, SIPs, PPF and gold, sized to income, age and risk comfort |
| Privacy by design | Per-user data isolation, leaked-password checks, auto sign-out after 15 minutes of inactivity |

## Tech stack

| Layer | Technology |
| --- | --- |
| Language | TypeScript, CSS |
| Framework | TanStack Start (React 19, TanStack Router, TanStack Query) |
| Styling / UI | Tailwind CSS 4, shadcn/ui (Radix UI), lucide-react |
| Charts | Recharts |
| Forms / validation | React Hook Form, Zod |
| Backend / auth / database | Lovable Cloud (managed backend with row-level security) |
| Tooling | Vite, Vitest, ESLint, Prettier |

## Getting started

**Prerequisites:** Node.js 20+ (or Bun) and Git.

```bash
git clone https://github.com/<your-username>/wiserupee.git
cd wiserupee
cp .env.example .env       # fill in your own values
npm install                # or: bun install
npm run dev
```

### Scripts

| Command | Purpose |
| --- | --- |
| `npm run dev` | Start the dev server |
| `npm run build` | Production build |
| `npm run preview` | Preview the production build |
| `npm run lint` | Run ESLint |
| `npm run format` | Format with Prettier |
| `npm test` | Run unit tests (Vitest) |

## Project structure

```
src/
├── routes/        # File-based pages and routes (TanStack Router)
├── components/ui/ # Reusable UI primitives (shadcn/ui)
├── hooks/         # Custom React hooks
├── lib/           # Utilities, error handling
├── test/          # Tests and test setup
├── styles.css     # Global styles and design tokens (CSS)
├── router.tsx     # Router configuration
└── server.ts      # Server entry point
docs/              # Architecture, features, roadmap
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for details.

## Security and privacy

- Each user can read only their own salary and expense data, enforced at the database level.
- Secrets are never committed. Use `.env` locally (git-ignored) and see [SECURITY.md](SECURITY.md).
- Passwords found in known data breaches are rejected at sign-up.

## Roadmap

CSV statement upload, ML-assisted categorisation, goal planner and a conversational assistant are planned. See [docs/ROADMAP.md](docs/ROADMAP.md).

## Disclaimer

WiseRupee provides educational planning support only. It does not offer guaranteed returns or professional investment advice.

## Team

| Name | Role | GitHub |
| --- | --- | --- |
| _Your name_ | _Role_ | [@username](https://github.com/username) |

## License

Released under the [MIT License](LICENSE).
