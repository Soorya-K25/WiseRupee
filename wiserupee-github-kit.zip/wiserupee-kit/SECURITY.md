# Security Policy

## Reporting a vulnerability

Please do **not** open a public issue for security problems. Email **<your-email@example.com>** with details and steps to reproduce. You will get a response within a reasonable time.

## Handling secrets

- Never commit API keys, tokens or passwords.
- Keep local values in `.env` (git-ignored); commit only `.env.example`.
- If a secret is committed by mistake, rotate it immediately; deleting the commit is not enough.

## Data

WiseRupee handles sensitive financial information. Per-user access is enforced at the database level, and contributors must not add logging of salary or expense data.
