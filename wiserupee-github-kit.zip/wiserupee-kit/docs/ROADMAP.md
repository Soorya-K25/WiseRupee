# Roadmap

- [ ] Secure CSV / statement upload
- [ ] ML-assisted transaction categorisation (improving the rule-based engine)
- [ ] Goal planner (emergency fund, education, travel)
- [ ] Conversational assistant ("Can I afford this?")
- [ ] User category corrections and feedback loop
- [ ] Evaluation with synthetic personas (student, single earner, couple, family)
