# Architecture

## Overview

WiseRupee is a full-stack TypeScript application built on TanStack Start (React 19, server-side rendering) with a managed backend for authentication and data.

```
 Browser (React UI)
        │
 TanStack Router (file-based routes in src/routes)
        │
 Server entry (src/server.ts) ── error handling / SSR
        │
 Managed backend: Auth + Database with row-level security
```

## Request flow

1. **Input**: the user enters salary, life stage (bachelor/married, children), goals and expenses.
2. **Process**: expenses are grouped into categories.
3. **Engine**: rule-based budget split and spending-pattern detection.
4. **Output**: budget, insights and an investment plan.

## Language and folder separation

| Concern | Language | Location |
| --- | --- | --- |
| Pages and routing | TypeScript (TSX) | `src/routes/` |
| Reusable UI | TypeScript (TSX) | `src/components/ui/` |
| Hooks and utilities | TypeScript | `src/hooks/`, `src/lib/` |
| Server entry and error handling | TypeScript | `src/server.ts`, `src/lib/` |
| Styling and design tokens | CSS | `src/styles.css` |
| Tooling config | JS / JSON / TOML | repo root |
| Tests | TypeScript | `src/test/` |

## Security model

- Row-level security: users can access only their own records.
- Leaked-password rejection and email confirmation on sign-up.
- Inactivity sign-out after 15 minutes.
