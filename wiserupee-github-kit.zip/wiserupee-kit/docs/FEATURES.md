# Features

## Available in the live prototype

- Account sign-up and sign-in with email confirmation
- Budget split by life stage (bachelor, married, with or without children)
- Expense logging and spending-pattern insights
- Investment plan covering emergency fund, insurance, SIPs, PPF and gold
- Privacy controls: per-user data isolation, inactivity sign-out

## Sample output

Married, 1 child, ₹85,000/month: Rent & Home ₹22,100 · Groceries ₹12,750 · Family Support ₹5,100 · Eating Out & Fun ₹2,550 · Savings & Investments ₹15,300.

_Educational guidance, not financial advice._
