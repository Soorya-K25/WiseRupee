# Contributing to WiseRupee

Thanks for your interest! Contributions of all sizes are welcome.

## Workflow

1. Fork the repository and create a branch: `git checkout -b feat/short-description`
2. Make your changes and keep them focused.
3. Run `npm run lint && npm test && npm run build` before pushing.
4. Open a pull request using the template.

## Commit messages

Use [Conventional Commits](https://www.conventionalcommits.org/):

`feat: add SIP calculator` · `fix: correct budget rounding` · `docs: update README` · `chore: bump dependencies`

## Code style

- TypeScript with strict typing; avoid `any`.
- Formatting is handled by Prettier (`npm run format`).
- Keep UI primitives in `src/components/ui/` and feature code in `src/routes/` or feature folders.

## Notes

This project is synced with Lovable. Avoid force-pushing or rewriting published history on the main branch.
